<?php

namespace Aepro;

$frontend = Frontend::instance();

?>
<div class="product">
	<?php do_action( 'aepro_single_data' ); ?>
</div>
